<?php

namespace app\api\model;

use think\Model;

class Sample extends Model
{

}

