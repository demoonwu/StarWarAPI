<?php
/**
 * Created by 七月.
 * User: 七月
 * Date: 2017/2/16
 * Time: 4:22
 */

namespace app\api\service;

use app\api\model\Image as ImageModel;
/**
 * 图片服务类
 */
class Image
{
    /**
     * @param $ids array
     * @return array
     */
//    public static function getImagesByIDs($ids)
//    {
//        if(empty($ids)){
//            return [];
//        }
//        $imgs = ImageModel::all($ids);
//        return $imgs;
//    }
}