<?php
/**
 * Created by PhpStorm.
 * User: bliss
 * Date: 2017/2/13
 * Time: 16:14
 */
namespace app\api\service;

use app\api\controller\BaseController;
use app\api\model\Banner as BannerModel;

/**
 *Banner
 */
class Banner extends BaseController
{
    
 
}