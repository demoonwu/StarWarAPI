<?php

namespace app\test\model;

use think\Model;

class Category extends Model
{
}
